#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
flat in int hudMode;
in vec2 hudLocal;
flat in vec4 hudData;
flat in vec4 hudExtra;

out vec4 fragColor;

#ifdef IS_GUI
#define HUD_ANIMATED
#moj_import <minecraft:globals.glsl>
const float HUD_MARGIN = 4.0;
const float HUD_RIGHT_WIDTH = 116.0;
const float HUD_RIGHT_TOP = 24.0;
const float HUD_LEFT_TOP = 0.0;
const float HUD_MINI_HALF = 54.0;
const float HUD_MINI_FRAME = 58.0;
const float HUD_MINI_TILE = 192.0;
const float HUD_MINI_ZOOM = 0.6666667;
const float HUD_TAB_MARGIN = 12.0;
const float HUD_TAB_SIDE = 124.0;
const float HUD_TAB_GRID = 6.0;
const float HUD_GLYPH = 8.0;
const float HUD_TAU = 6.2831853;
const int HUD_CANVAS_MAGIC = 11920285;

vec3 hud_palette(int index) {
    if (index < 240) {
        return vec3(float(index / 40) / 5.0, float((index / 5) % 8) / 7.0, float(index % 5) / 4.0);
    }
    if (index == 241) {
        return vec3(0.667, 0.667, 0.667);
    }
    if (index == 242) {
        return vec3(0.333, 0.333, 0.333);
    }
    if (index == 243) {
        return vec3(1.0, 0.333, 0.333);
    }
    if (index == 244) {
        return vec3(1.0, 0.667, 0.0);
    }
    if (index == 245) {
        return vec3(0.333, 1.0, 0.333);
    }
    if (index == 246) {
        return vec3(1.0, 0.333, 1.0);
    }
    if (index == 247) {
        return vec3(0.0, 0.757, 1.0);
    }
    if (index == 248) {
        return vec3(1.0, 1.0, 0.333);
    }
    if (index == 249) {
        return vec3(0.0, 0.0, 0.0);
    }
    return vec3(1.0, 1.0, 1.0);
}

vec3 hud_team_color(int index) {
    if (index == 1) {
        return hud_palette(247);
    }
    if (index == 2) {
        return hud_palette(245);
    }
    if (index == 3) {
        return hud_palette(243);
    }
    if (index == 4) {
        return hud_palette(244);
    }
    if (index == 5) {
        return hud_palette(246);
    }
    return vec3(1.0, 0.886, 0.282);
}

float hud_time() {
#ifdef HUD_ANIMATED
    return GameTime * 1200.0;
#else
    return 0.0;
#endif
}

float hud_square(vec2 point) {
    return max(abs(point.x), abs(point.y));
}

int hud_data(vec4 color) {
    ivec3 code = ivec3(round(color.rgb * 255.0));
    return code.r * 65536 + code.g * 256 + code.b;
}

vec2 hud_tab_origin(float width, float height, out float size) {
    size = min(height - HUD_TAB_MARGIN * 2.0, width - HUD_TAB_SIDE * 2.0);
    size = max(size, min(width, height) * 0.5);
    return vec2((width - size) * 0.5, (height - size) * 0.5);
}

vec2 hud_mini_center(float width) {
    return vec2(width - HUD_MARGIN - HUD_MINI_FRAME, HUD_RIGHT_TOP + HUD_MINI_FRAME);
}

vec3 hud_tile_texel(sampler2D sampler, ivec2 point, ivec2 rectMin) {
    ivec2 local = clamp(point - rectMin, ivec2(0), ivec2(int(HUD_MINI_TILE) - 1));
    vec4 texel = texelFetch(sampler, rectMin + local, 0);
    if (texel.a < 0.5) {
        ivec2 inward = ivec2(local.x == 0 ? 1 : -1, local.y == 0 ? 1 : -1);
        texel = texelFetch(sampler, rectMin + local + inward, 0);
    }
    return texel.rgb;
}

vec3 hud_tile_sample(sampler2D sampler, vec2 uv, vec2 rectMin, float softness) {
    vec2 texel = uv * vec2(textureSize(sampler, 0)) - 0.5;
    vec2 base = floor(texel);
    vec2 footprint = max(fwidth(texel), vec2(softness));
    vec2 blend = clamp((texel - base - 0.5) / footprint + 0.5, 0.0, 1.0);
    ivec2 origin = ivec2(base);
    ivec2 rect = ivec2(rectMin);
    vec3 top = mix(hud_tile_texel(sampler, origin, rect), hud_tile_texel(sampler, origin + ivec2(1, 0), rect), blend.x);
    vec3 bottom = mix(hud_tile_texel(sampler, origin + ivec2(0, 1), rect), hud_tile_texel(sampler, origin + ivec2(1, 1), rect), blend.x);
    return mix(top, bottom, blend.y);
}

vec4 hud_over(vec4 below, vec4 above) {
    float alpha = above.a + below.a * (1.0 - above.a);
    if (alpha <= 0.0) {
        return vec4(0.0);
    }
    return vec4((above.rgb * above.a + below.rgb * below.a * (1.0 - above.a)) / alpha, alpha);
}

float hud_fill(float distance, float pixel) {
    return clamp(0.5 - distance / pixel, 0.0, 1.0);
}

float hud_band(float distance, float width, float pixel) {
    return clamp(0.5 - (abs(distance) - width * 0.5) / pixel, 0.0, 1.0);
}

vec2 hud_rotate(vec2 point, float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return vec2(point.x * c + point.y * s, -point.x * s + point.y * c);
}

float hud_polygon(vec2 point, vec2 a, vec2 b, vec2 c, vec2 d) {
    vec2 vertices[4] = vec2[4](a, b, c, d);
    float distance = dot(point - vertices[0], point - vertices[0]);
    float inside = 1.0;
    for (int i = 0, j = 3; i < 4; j = i, i++) {
        vec2 edge = vertices[j] - vertices[i];
        vec2 toPoint = point - vertices[i];
        vec2 closest = toPoint - edge * clamp(dot(toPoint, edge) / dot(edge, edge), 0.0, 1.0);
        distance = min(distance, dot(closest, closest));
        bvec3 crossing = bvec3(point.y >= vertices[i].y, point.y < vertices[j].y, edge.x * toPoint.y > edge.y * toPoint.x);
        if (all(crossing) || all(not(crossing))) {
            inside = -inside;
        }
    }
    return inside * sqrt(distance);
}

float hud_arrow_distance(vec2 point, float size) {
    return hud_polygon(point / size, vec2(0.0, -0.5), vec2(0.4, 0.42), vec2(0.0, 0.22), vec2(-0.4, 0.42)) * size;
}

vec4 hud_arrow(vec2 point, float angle, float size, vec3 fill, vec3 edge, float pixel) {
    vec2 local = hud_rotate(point, angle);
    float distance = hud_arrow_distance(local, size);
    float outline = max(1.2 * pixel, size * 0.12);
    vec4 shadow = vec4(0.03, 0.02, 0.06, 0.55 * hud_fill(hud_arrow_distance(local - vec2(0.0, size * 0.08), size) - outline * 2.2, pixel * 2.0));
    vec4 border = vec4(edge, hud_fill(distance - outline, pixel));
    float shade = clamp(0.88 + local.x / size * 0.35, 0.6, 1.1);
    vec4 body = vec4(fill * shade, hud_fill(distance, pixel));
    return hud_over(hud_over(shadow, border), body);
}

const int HUD_CRATE_W = 11;
const int HUD_CRATE_H = 12;
const int HUD_CRATE_PIXELS[132] = int[132](
    0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 1, 2, 3, 3, 3, 2, 1, 0, 0,
    0, 1, 2, 2, 3, 3, 3, 2, 2, 1, 0,
    1, 2, 2, 2, 3, 3, 3, 2, 2, 2, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    0, 0, 4, 0, 0, 0, 0, 0, 4, 0, 0,
    0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0,
    0, 0, 1, 5, 5, 6, 5, 5, 1, 0, 0,
    0, 0, 1, 6, 6, 6, 6, 6, 1, 0, 0,
    0, 0, 1, 5, 5, 6, 5, 5, 1, 0, 0,
    0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0
);

int hud_crate_cell(int x, int y) {
    if (x < 0 || y < 0 || x >= HUD_CRATE_W || y >= HUD_CRATE_H) {
        return 0;
    }
    return HUD_CRATE_PIXELS[y * HUD_CRATE_W + x];
}

vec3 hud_crate_color(int cell) {
    if (cell == 1) {
        return vec3(0.07, 0.04, 0.10);
    }
    if (cell == 2) {
        return vec3(0.93, 0.20, 0.22);
    }
    if (cell == 3) {
        return vec3(0.98, 0.96, 0.93);
    }
    if (cell == 4) {
        return vec3(0.86, 0.80, 0.70);
    }
    if (cell == 5) {
        return vec3(0.86, 0.55, 0.22);
    }
    return vec3(0.55, 0.32, 0.10);
}

vec4 hud_crate(vec2 point, float size, float pixel) {
    float cell = max(1.0, floor(size / float(HUD_CRATE_W) + 0.5));
    vec2 origin = vec2(-float(HUD_CRATE_W), -float(HUD_CRATE_H)) * cell * 0.5;
    ivec2 grid = ivec2(floor((point - origin) / cell));
    int value = hud_crate_cell(grid.x, grid.y);
    if (value != 0) {
        return vec4(hud_crate_color(value), 1.0);
    }
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            if (hud_crate_cell(grid.x + dx, grid.y + dy) != 0) {
                return vec4(0.05, 0.03, 0.09, 0.45);
            }
        }
    }
    return vec4(0.0);
}

vec4 hud_dragon(vec2 point, float angle, float size, float pixel) {
    vec2 local = hud_rotate(point, angle);
    float badge = length(local) - size * 0.48;
    vec4 color = hud_over(vec4(0.05, 0.03, 0.09, 0.55 * hud_fill(badge - size * 0.08, pixel * 2.0)),
        vec4(0.08, 0.04, 0.12, hud_fill(badge, pixel)));
    color = hud_over(color, vec4(0.69, 0.36, 1.0, hud_fill(badge + size * 0.07, pixel)));
    float wings = hud_polygon(local / size, vec2(0.0, -0.3), vec2(0.34, 0.16), vec2(0.0, 0.04), vec2(-0.34, 0.16)) * size;
    color = hud_over(color, vec4(1.0, 0.95, 1.0, hud_fill(wings, pixel)));
    return color;
}

vec4 hud_zone(int variant, vec2 delta, float radius, float width, float pixel) {
    float distance = length(delta);
    if (variant == 2) {
        float period = max(6.0, width * 5.0);
        float arc = atan(delta.y, delta.x) * radius;
        float dash = (abs(fract(arc / period) - 0.5) - 0.18) * period;
        return vec4(1.0, 1.0, 1.0, 0.95 * hud_band(distance - radius, width * 0.75, pixel) * hud_fill(-dash, pixel));
    }
    vec3 ringColor = variant == 1 ? vec3(1.0) : vec3(1.0, 0.36, 1.0);
    float outside = clamp((distance - radius) / pixel + 0.5, 0.0, 1.0);
    float stripe = smoothstep(0.35, 0.65, 0.5 + 0.5 * sin((gl_FragCoord.x + gl_FragCoord.y) * 0.30));
    vec4 storm = vec4(0.34, 0.12, 0.66, (0.20 + 0.08 * stripe) * outside);
    float breathe = variant == 0 ? 0.75 + 0.25 * sin(hud_time() * 5.0) : 1.0;
    vec4 ring = vec4(ringColor, hud_band(distance - radius, width, pixel));
    vec4 glow = vec4(ringColor, 0.35 * breathe * hud_band(distance - radius, width * 3.0, pixel * 3.0));
    return hud_over(hud_over(storm, glow), ring);
}

vec4 hud_beacon(vec2 point, float size, vec3 tint, float pixel) {
    float distance = length(point);
#ifdef HUD_ANIMATED
    float phase = fract(hud_time() / 1.6);
    float radius = size * (0.6 + 1.0 * phase);
    float alpha = (1.0 - phase) * (1.0 - phase) * 0.9;
#else
    float radius = size * 1.05;
    float alpha = 0.5;
#endif
    vec4 shade = vec4(0.05, 0.03, 0.09, 0.45 * alpha * hud_band(distance - radius, max(2.4, size * 0.2), pixel * 2.0));
    return hud_over(shade, vec4(tint, alpha * hud_band(distance - radius, max(1.2, size * 0.1), pixel)));
}

vec4 hud_guide(vec2 point, vec2 center, float radius, float pixel) {
    float reach = length(center);
    if (reach <= radius + 1.0) {
        return vec4(0.0);
    }
    vec2 direction = center / reach;
    float span = min(reach - radius, HUD_MINI_HALF * 1.5);
    float along = dot(point, direction);
    float across = dot(point, vec2(-direction.y, direction.x));
    if (along < 6.0 || along > span) {
        return vec4(0.0);
    }
    float spacing = 4.5;
    float shifted = along - hud_time() * 6.0;
    float spot = length(vec2(shifted - (floor(shifted / spacing) + 0.5) * spacing, across));
    vec4 color = vec4(0.05, 0.03, 0.09, 0.8 * hud_fill(spot - 2.0, pixel));
    return hud_over(color, vec4(1.0, 1.0, 1.0, hud_fill(spot - 1.15, pixel)));
}

vec4 hud_route(vec2 point, vec2 origin, float angle, float pixel) {
    vec2 direction = vec2(cos(angle), sin(angle));
    vec2 delta = point - origin;
    float along = dot(delta, direction);
    float across = dot(delta, vec2(-direction.y, direction.x));
    float dash = step(0.38, fract(along / 9.0));
    vec4 shadow = vec4(0.05, 0.03, 0.09, 0.45 * hud_band(across, 3.4, pixel));
    vec4 line = vec4(1.0, 0.95, 0.75, 0.95 * dash * hud_band(across, 1.4, pixel));
    float phase = fract(along / 30.0) * 30.0 - 15.0;
    float chevron = abs(abs(across) * 0.9 + phase) - 0.9;
    vec4 head = vec4(1.0, 0.95, 0.75, hud_fill(chevron, pixel) * step(abs(across), 4.0) * step(-2.0, phase) * step(phase, 2.0));
    return hud_over(hud_over(shadow, line), head);
}

float hud_letter_n(vec2 point) {
    ivec2 cell = ivec2(floor(point));
    if (cell.x < 0 || cell.y < 0 || cell.x > 4 || cell.y > 6) {
        return 0.0;
    }
    int rows[7] = int[7](17, 25, 21, 19, 17, 17, 17);
    return float((rows[cell.y] >> (4 - cell.x)) & 1);
}

vec4 hud_tooltip(vec2 point, vec2 extent, float verticalSpan) {
    vec2 q = abs(point) - extent;
    float edge = max(q.x, q.y);
    if (edge < 0.0) {
        float rim = clamp((edge + 6.0) / 6.0, 0.0, 1.0);
        return vec4(0.0, 0.0, 0.0, 0.3 * rim * rim);
    }
    if (edge >= 4.0 || (q.x >= 3.0 && q.y >= 3.0)) {
        return vec4(0.0);
    }
    vec4 color = vec4(0.063, 0.0, 0.063, 0.94);
    if (edge >= 2.0 && edge < 3.0) {
        float t = clamp(point.y / verticalSpan * 0.5 + 0.5, 0.0, 1.0);
        vec3 border = mix(vec3(0.314, 0.0, 1.0), vec3(0.157, 0.0, 0.498), t);
        color = hud_over(color, vec4(border, 0.6));
    }
    return color;
}

vec4 hud_frame_square(vec2 point) {
    vec4 color = hud_tooltip(point, vec2(HUD_MINI_HALF), HUD_MINI_HALF + 4.0);
    vec2 tab = point - vec2(0.0, -(HUD_MINI_HALF + 3.0));
    vec4 badge = hud_tooltip(tab, vec2(3.5, 4.5), 8.5);
    if (max(abs(tab.x) - 3.5, abs(tab.y) - 4.5) < 0.0) {
        badge = vec4(0.063, 0.0, 0.063, 0.94);
    }
    color = hud_over(color, badge);
    vec2 glyph = tab + vec2(2.5, 3.5);
    color = hud_over(color, vec4(0.25, 0.25, 0.25, hud_letter_n(glyph - vec2(1.0, 1.0))));
    color = hud_over(color, vec4(1.0, 1.0, 1.0, hud_letter_n(glyph)));
    return color;
}

vec4 hud_tab_frame(vec2 point, float size, float pixel) {
    vec2 centered = point - vec2(size * 0.5);
    return hud_tooltip(centered, vec2(size * 0.5), size * 0.5 + 4.0);
}

bool hud_fragment(sampler2D sampler, int mode, vec2 local, vec4 data, vec4 extra, vec2 uv, out vec4 result) {
    result = vec4(0.0);
    if (mode == 0) {
        return false;
    }
    float pixel = clamp(fwidth(local.x), 0.05, 1.0);
    if (mode == 2 && hud_square(local) > HUD_MINI_HALF) {
        discard;
    }
    if (mode == 1 || mode == 2) {
        result = vec4(hud_tile_sample(sampler, uv, extra.xy, mode == 2 ? 0.35 : 0.0), 1.0);
        return true;
    }
    if (mode == 101 || mode == 102) {
        if (hud_square(local) > HUD_MINI_HALF) {
            discard;
        }
        int variant = mode == 102 ? 2 : (data.w > 0.5 ? 0 : 1);
        result = hud_zone(variant, local - data.xy, data.z, 1.6, pixel);
        if (mode == 102) {
            result = hud_over(result, hud_guide(local, data.xy, data.z, pixel));
        }
    } else if (mode == 103) {
        result = hud_arrow(local, data.x, 10.0, vec3(1.0, 0.886, 0.282), vec3(1.0), pixel);
    } else if (mode == 104 || mode == 105) {
        float scale = extra.z > 0.5 ? 0.8 : 1.0;
        result = mode == 104 ? hud_arrow(local, data.x, 9.0 * scale, hud_team_color(int(data.y)), vec3(0.05, 0.03, 0.09), pixel) : hud_crate(local, 11.0 * scale, pixel);
    } else if (mode == 106) {
        result = hud_frame_square(local);
    } else if (mode >= 111 && mode <= 113) {
        float size = extra.x;
        if (local.x < 0.0 || local.y < 0.0 || local.x > size || local.y > size) {
            discard;
        }
        if (mode == 113) {
            result = hud_route(local, data.xy, data.z, pixel);
        } else {
            int variant = mode == 112 ? 2 : (data.w > 0.5 ? 0 : 1);
            result = hud_zone(variant, local - data.xy, data.z, 2.0, pixel);
        }
    } else if (mode >= 114 && mode <= 117) {
        float size = extra.z;
        if (extra.x < 0.0 || extra.y < 0.0 || extra.x > size || extra.y > size) {
            discard;
        }
        if (mode == 114) {
            result = hud_over(hud_beacon(local, data.y, vec3(1.0, 0.95, 0.6), pixel),
                hud_arrow(local, data.x, data.y, vec3(1.0, 0.886, 0.282), vec3(1.0), pixel));
        } else if (mode == 115) {
            result = hud_arrow(local, data.x, data.y, hud_team_color(int(data.z)), vec3(0.05, 0.03, 0.09), pixel);
        } else if (mode == 116) {
            result = hud_crate(local, data.y, pixel);
        } else {
            result = hud_dragon(local, data.x, data.y, pixel);
        }
    } else if (mode == 118) {
        result = hud_tab_frame(local, extra.x, pixel);
    } else {
        return false;
    }
    if (result.a < 0.01) {
        discard;
    }
    return true;
}
#endif

void main() {
#ifdef IS_GUI
    vec4 hud;
    if (hud_fragment(Sampler0, hudMode, hudLocal, hudData, hudExtra, texCoord0, hud)) {
        fragColor = hud;
        return;
    }
#endif
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
