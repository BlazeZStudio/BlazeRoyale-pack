#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

#ifdef IS_GUI
uniform sampler2D Sampler0;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
flat out int hudMode;
out vec2 hudLocal;
flat out vec4 hudData;
flat out vec4 hudExtra;

#ifdef IS_GUI
#define HUD_ANIMATED
#moj_import <minecraft:globals.glsl>
const float HUD_MARGIN = 4.0;
const float HUD_RIGHT_WIDTH = 116.0;
const float HUD_RIGHT_TOP = 24.0;
const float HUD_LEFT_TOP = 0.0;
const float HUD_MINI_HALF = 54.0;
const float HUD_MINI_FRAME = 58.0;
const float HUD_MINI_TILE = 192.0;
const float HUD_MINI_ZOOM = 0.6666667;
const float HUD_TAB_MARGIN = 12.0;
const float HUD_TAB_SIDE = 124.0;
const float HUD_TAB_GRID = 6.0;
const float HUD_GLYPH = 8.0;
const float HUD_TAU = 6.2831853;
const int HUD_CANVAS_MAGIC = 11920285;

vec3 hud_palette(int index) {
    if (index < 240) {
        return vec3(float(index / 40) / 5.0, float((index / 5) % 8) / 7.0, float(index % 5) / 4.0);
    }
    if (index == 241) {
        return vec3(0.667, 0.667, 0.667);
    }
    if (index == 242) {
        return vec3(0.333, 0.333, 0.333);
    }
    if (index == 243) {
        return vec3(1.0, 0.333, 0.333);
    }
    if (index == 244) {
        return vec3(1.0, 0.667, 0.0);
    }
    if (index == 245) {
        return vec3(0.333, 1.0, 0.333);
    }
    if (index == 246) {
        return vec3(1.0, 0.333, 1.0);
    }
    if (index == 247) {
        return vec3(0.0, 0.757, 1.0);
    }
    if (index == 248) {
        return vec3(1.0, 1.0, 0.333);
    }
    if (index == 249) {
        return vec3(0.0, 0.0, 0.0);
    }
    return vec3(1.0, 1.0, 1.0);
}

vec3 hud_team_color(int index) {
    if (index == 1) {
        return hud_palette(247);
    }
    if (index == 2) {
        return hud_palette(245);
    }
    if (index == 3) {
        return hud_palette(243);
    }
    if (index == 4) {
        return hud_palette(244);
    }
    if (index == 5) {
        return hud_palette(246);
    }
    return vec3(1.0, 0.886, 0.282);
}

float hud_time() {
#ifdef HUD_ANIMATED
    return GameTime * 1200.0;
#else
    return 0.0;
#endif
}

float hud_square(vec2 point) {
    return max(abs(point.x), abs(point.y));
}

int hud_data(vec4 color) {
    ivec3 code = ivec3(round(color.rgb * 255.0));
    return code.r * 65536 + code.g * 256 + code.b;
}

vec2 hud_tab_origin(float width, float height, out float size) {
    size = min(height - HUD_TAB_MARGIN * 2.0, width - HUD_TAB_SIDE * 2.0);
    size = max(size, min(width, height) * 0.5);
    return vec2((width - size) * 0.5, (height - size) * 0.5);
}

vec2 hud_mini_center(float width) {
    return vec2(width - HUD_MARGIN - HUD_MINI_FRAME, HUD_RIGHT_TOP + HUD_MINI_FRAME);
}

bool hud_shift(vec4 color, float halfWidth, inout vec3 position, out vec4 shifted) {
    ivec3 code = ivec3(round(color.rgb * 255.0));
    shifted = color;
    if (code.r != 254 || (code.g != 1 && code.g != 2)) {
        return false;
    }
    if (code.g == 1) {
        position.x += halfWidth - HUD_MARGIN - HUD_RIGHT_WIDTH;
        position.y += HUD_RIGHT_TOP;
    } else {
        position.x += HUD_MARGIN - halfWidth;
        position.y += HUD_LEFT_TOP;
    }
    shifted = vec4(hud_palette(code.b), color.a);
    return true;
}

vec2 hud_corner(int corner) {
    return vec2(corner == 2 || corner == 3 ? 1.0 : 0.0, corner == 1 || corner == 2 ? 1.0 : 0.0);
}

bool hud_tag(sampler2D sampler, vec2 uv, out int role, out int param, out int corner) {
    ivec2 size = textureSize(sampler, 0);
    ivec2 point = ivec2(floor(uv * vec2(size) + 0.5));
    for (int index = 0; index < 4; index++) {
        ivec2 texel = clamp(point - ivec2(index % 2, index / 2), ivec2(0), size - 1);
        ivec4 tag = ivec4(round(texelFetch(sampler, texel, 0) * 255.0));
        if (tag.a == 1 && tag.r >= 200 && tag.r <= 203) {
            role = tag.g;
            param = tag.b;
            corner = tag.r - 200;
            return true;
        }
    }
    role = 0;
    param = 0;
    corner = 0;
    return false;
}

bool hud_place_tile(
    sampler2D sampler,
    vec3 inPosition,
    vec4 inColor,
    vec2 uv,
    float width,
    float height,
    out vec3 position,
    out int mode,
    out vec2 local,
    out vec4 extra
) {
    int role;
    int param;
    int corner;
    position = inPosition;
    mode = 0;
    local = vec2(0.0);
    extra = vec4(0.0);
    if (!hud_tag(sampler, uv, role, param, corner)) {
        return false;
    }
    vec2 offset = hud_corner(corner);
    extra = vec4(floor(uv * vec2(textureSize(sampler, 0)) + 0.5) - offset * HUD_MINI_TILE, 0.0, 0.0);
    float layoutX = inPosition.x - floor(width * 0.5 + 0.01) - offset.x * HUD_GLYPH;
    vec2 target;
    if (role == 1) {
        float tabSize;
        vec2 tabOrigin = hud_tab_origin(width, height, tabSize);
        float cell = tabSize / HUD_TAB_GRID;
        target = tabOrigin + (vec2(float(param % 6), float(param / 6)) + offset) * cell;
        local = target - tabOrigin;
        mode = 1;
    } else if (role == 2) {
        vec2 center = hud_mini_center(width);
        float offsetY = float(hud_data(inColor) - 8388608) / 256.0;
        target = center + (vec2(layoutX, offsetY) + offset * HUD_MINI_TILE) * HUD_MINI_ZOOM;
        local = target - center;
        mode = 2;
    } else {
        return false;
    }
    position = vec3(target, inPosition.z);
    return true;
}

bool hud_canvas_type(sampler2D sampler, vec2 uv, out int corner, out int type) {
    ivec2 size = textureSize(sampler, 0);
    ivec2 point = ivec2(floor(uv * vec2(size) + 0.5));
    for (int candidate = 0; candidate < 4; candidate++) {
        vec2 offset = hud_corner(candidate);
        ivec2 origin = point - ivec2(offset);
        ivec2 inward = ivec2(1 - 2 * int(offset.x), 1 - 2 * int(offset.y));
        int low = 0;
        int high = 0;
        for (int bit = 0; bit < 32; bit++) {
            ivec2 texel = clamp(origin + ivec2(bit % 6, bit / 6) * inward, ivec2(0), size - 1);
            if (texelFetch(sampler, texel, 0).r > 0.5) {
                if (bit < 24) {
                    low += 1 << bit;
                } else {
                    high += 1 << (bit - 24);
                }
            }
        }
        if (low == HUD_CANVAS_MAGIC) {
            corner = candidate;
            type = high;
            return true;
        }
    }
    corner = 0;
    type = 0;
    return false;
}

bool hud_place_canvas(
    sampler2D sampler,
    vec3 inPosition,
    vec4 inColor,
    vec2 uv,
    float width,
    float height,
    out vec3 position,
    out int mode,
    out vec2 local,
    out vec4 data,
    out vec4 extra
) {
    int corner;
    int type;
    position = inPosition;
    mode = 0;
    local = vec2(0.0);
    data = vec4(0.0);
    extra = vec4(0.0);
    if (!hud_canvas_type(sampler, uv, corner, type)) {
        return false;
    }
    vec2 offset = hud_corner(corner);
    vec2 sign = offset * 2.0 - 1.0;
    float layoutX = inPosition.x - floor(width * 0.5 + 0.01) - offset.x * HUD_GLYPH;
    int value = hud_data(inColor);
    vec2 center = hud_mini_center(width);
    float tabSize;
    vec2 tabOrigin = hud_tab_origin(width, height, tabSize);
    vec2 target;
    if (type == 1 || type == 2) {
        float angle = float(value / 4096) / 4096.0 * HUD_TAU;
        float radius = exp(float((value / 2) % 2048) * 0.0044020);
        float distance = (radius + clamp(layoutX, -400.0, 400.0)) * HUD_MINI_ZOOM;
        target = center + sign * (HUD_MINI_HALF + 1.0);
        local = target - center;
        data = vec4(cos(angle) * distance, sin(angle) * distance, radius * HUD_MINI_ZOOM, float(value % 2));
    } else if (type == 3) {
        target = center + sign * 9.0;
        local = target - center;
        data = vec4(float(value / 32768) / 512.0 * HUD_TAU, 0.0, 0.0, 0.0);
    } else if (type == 4 || type == 5) {
        vec2 offsetIcon = vec2(layoutX, float(value / 4096 - 2048) * 0.5) * HUD_MINI_ZOOM;
        float reach = hud_square(offsetIcon);
        float limit = HUD_MINI_HALF - 5.0;
        float edge = 0.0;
        if (reach > limit) {
            offsetIcon *= limit / reach;
            edge = 1.0;
        }
        vec2 icon = center + offsetIcon;
        target = icon + sign * 7.5;
        local = target - icon;
        extra = vec4(offsetIcon, edge, 0.0);
        data = vec4(float((value / 32) % 128) / 128.0 * HUD_TAU, float(value % 32), 0.0, 0.0);
    } else if (type == 6) {
        target = center + sign * (HUD_MINI_FRAME + 9.0);
        local = target - center;
    } else if (type >= 11 && type <= 13) {
        target = tabOrigin + offset * tabSize;
        local = target - tabOrigin;
        vec2 point = vec2((layoutX + 128.0) / 256.0, float(value / 4096) / 4096.0) * tabSize;
        float third = type == 13 ? float(value % 4096) / 4096.0 * HUD_TAU : float((value / 2) % 2048) / 2048.0 * tabSize;
        data = vec4(point, third, float(value % 2));
        extra = vec4(tabSize, 0.0, 0.0, 0.0);
    } else if (type >= 14 && type <= 17) {
        float size = max(7.0, tabSize * (type == 17 ? 0.05 : 0.034));
        vec2 icon = tabOrigin + vec2((layoutX + 128.0) / 256.0, float(value / 4096) / 4096.0) * tabSize;
        target = icon + sign * size * (type == 14 ? 1.7 : 0.8);
        local = target - icon;
        extra = vec4(icon - tabOrigin, tabSize, 0.0);
        float angle = type == 15 ? float((value / 32) % 128) / 128.0 * HUD_TAU : float(value % 4096) / 4096.0 * HUD_TAU;
        data = vec4(angle, size, float(value % 32), 0.0);
    } else if (type == 18) {
        target = tabOrigin + offset * tabSize + sign * 6.0;
        local = target - tabOrigin;
        extra = vec4(tabSize, 0.0, 0.0, 0.0);
    } else {
        return false;
    }
    mode = 100 + type;
    position = vec3(target, inPosition.z);
    return true;
}
#endif

void main() {
    vec3 position = Position;
    vec4 color = Color;
    hudMode = 0;
    hudLocal = vec2(0.0);
    hudData = vec4(0.0);
    hudExtra = vec4(0.0);
#ifdef IS_GUI
    vec3 placed;
    int mode;
    vec2 local;
    vec4 tileExtra;
#ifdef IS_GRAYSCALE
    vec4 data;
    vec4 extra;
    if (hud_place_canvas(Sampler0, Position, Color, UV0, 2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1]), placed, mode, local, data, extra)) {
        position = placed;
        color = vec4(1.0);
        hudMode = mode;
        hudLocal = local;
        hudData = data;
        hudExtra = extra;
    }
#else
    if (hud_place_tile(Sampler0, Position, Color, UV0, 2.0 / abs(ProjMat[0][0]), 2.0 / abs(ProjMat[1][1]), placed, mode, local, tileExtra)) {
        position = placed;
        color = vec4(1.0);
        hudMode = mode;
        hudLocal = local;
        hudExtra = tileExtra;
    } else {
        vec4 shifted;
        if (hud_shift(Color, 1.0 / abs(ProjMat[0][0]), position, shifted)) {
            color = shifted;
        }
    }
#endif
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(position);
    cylindricalVertexDistance = fog_cylindrical_distance(position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = color;
#endif
    texCoord0 = UV0;
}
